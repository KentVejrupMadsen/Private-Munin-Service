
class Setting:
    """ """

    def __init__(self):

        pass

