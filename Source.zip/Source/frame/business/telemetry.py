
class Telemetry:
    """ """

    def __init__(self):

        pass

