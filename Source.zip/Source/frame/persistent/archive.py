from frame.persistent.configuration import Configuration


class Archive:
    """ """

    def __init__(self):

        pass
