
class Configuration:
    """ """

    def __init__(self):

        pass
