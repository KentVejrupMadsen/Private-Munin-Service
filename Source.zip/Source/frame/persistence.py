from frame.persistent.archive import Archive


class Persistence:
    """ """

    def __init__(self):
        self.archive = Archive()
        pass

    def execute(self):
        pass
