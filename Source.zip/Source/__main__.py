from frame.application import Application


def main():
    app = Application()

    app.execute()


if __name__ == '__main__':
    # 
    main()